<?php
require_once 'database.php';
session_start();

if(isset($_POST['loginAuth'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $checkSql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $checkSql);
    $row = mysqli_fetch_assoc($result);

    if($row && password_verify($password, $row['password'])){
        $_SESSION['userID'] = $row['userID'];
        header("Location: ../frontend/dashboard.php");
        exit();
    }else{
        header("Location: ../index.php?invalid");
        exit();
    }
}
?>