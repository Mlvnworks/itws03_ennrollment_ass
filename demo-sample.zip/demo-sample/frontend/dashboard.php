<?php
require_once '../backend/database.php'; //always do this in every page
session_start();

if(!isset($_SESSION['userID'])){
    header("Location: ../index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Enrollment System Dashboard</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>

body{
background:#f5f6fa;
}

/* Sidebar */
.sidebar{
height:100vh;
background:#0d6efd;
color:white;
padding-top:20px;
}

.sidebar a{
color:white;
text-decoration:none;
display:block;
padding:10px 20px;
}

.sidebar a:hover{
background:rgba(255,255,255,0.2);
border-radius:5px;
}

.sidebar .submenu{
padding-left:20px;
font-size:14px;
}

/* Top navbar */
.topbar{
background:white;
border-bottom:1px solid #ddd;
}

/* Dashboard cards */
.card-box{
border-radius:10px;
}

</style>
</head>

<body>

<div class="container-fluid">
<div class="row">

<!-- Sidebar -->
<?php
include "nav.php";
?>


<!-- Main Content -->
<div class="col-md-10 p-0">

<!-- Top Navbar -->
<nav class="navbar navbar-expand-lg topbar px-3">
<div class="container-fluid">

<h5 class="mb-0">Dashboard</h5>

<div class="ms-auto">
<span class="me-3"><i class="bi bi-person-circle"></i> Admin</span>
</div>

</div>
</nav>


<!-- Dashboard Content -->
<div class="container mt-4">

<h4>Enrollment System Dashboard</h4>
<p class="text-muted">Welcome to the Student Enrollment Management System.</p>

<div class="row mt-4">

<div class="col-md-3">
<div class="card shadow card-box p-3 text-center">
<i class="bi bi-people fs-1 text-primary"></i>
<h5 class="mt-2">Students</h5>
<p>Total Students</p>
</div>
</div>

<div class="col-md-3">
<div class="card shadow card-box p-3 text-center">
<i class="bi bi-journal-bookmark fs-1 text-success"></i>
<h5 class="mt-2">Courses</h5>
<p>Available Courses</p>
</div>
</div>

<div class="col-md-3">
<div class="card shadow card-box p-3 text-center">
<i class="bi bi-building fs-1 text-warning"></i>
<h5 class="mt-2">Campus</h5>
<p>Campus List</p>
</div>
</div>

<div class="col-md-3">
<div class="card shadow card-box p-3 text-center">
<i class="bi bi-pencil-square fs-1 text-danger"></i>
<h5 class="mt-2">Enrollments</h5>
<p>Student Enrollments</p>
</div>
</div>

</div>

</div>

</div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>